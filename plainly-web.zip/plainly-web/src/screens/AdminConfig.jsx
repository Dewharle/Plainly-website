"use client";

// Generated from Claude Design: W15-AdminConfig.dc.html (ADM-06 · Configuration)
// Do not hand-edit: change the design and re-run `npm run convert`.

import Link from "next/link";
import { DCLogic, useDCLogic } from "@/lib/dc";

const css = "body{margin:0}\na{color:#0E5A3C}a:hover{color:#0A4630}\n.tip{position:relative;display:inline-flex;align-items:center}\n.tip>[role=tooltip]{position:absolute;bottom:calc(100% + 10px);left:50%;transform:translateX(-50%);width:max-content;max-width:260px;padding:8px 10px;border-radius:8px;background:#15201A;color:#FFFFFF;font:500 12px/1.45 'Figtree',sans-serif;text-align:left;opacity:0;pointer-events:none;transition:opacity .2s;z-index:20;box-shadow:0 8px 24px -8px rgba(21,32,26,.35)}\n.tip:hover>[role=tooltip],.tip:focus-within>[role=tooltip],.tip.is-open>[role=tooltip]{opacity:1}\n@media (max-width: 640px){.tip>[role=tooltip]{left:auto;right:-8px;transform:none;max-width:min(260px,78vw)}}";

class AdminConfigLogic extends DCLogic {
  renderVals() { return {}; }
}

export default function AdminConfig() {
  useDCLogic(AdminConfigLogic);
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: css }} />
      <div style={{ width: "100%", minHeight: "1720px", boxSizing: "border-box", background: "#F6F4EE", color: "#15201A", fontFamily: "'Figtree', 'Segoe UI', system-ui, sans-serif", fontSize: "15px", lineHeight: "1.5", display: "flex", flexDirection: "column" }}>
        <header style={{ minHeight: "64px", boxSizing: "border-box", background: "#FFFFFF", borderBottom: "1px solid #E3DFD4", padding: "10px 24px", display: "flex", flexWrap: "wrap", alignItems: "center", gap: "12px 20px" }}>
          <Link href="/browse" aria-label="Plainly home, back office" style={{ display: "flex", alignItems: "center", gap: "10px", textDecoration: "none", color: "#15201A" }}>
            <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true">
              <rect width="32" height="32" rx="9" fill="#0E5A3C"></rect>
              <path d="M10 25V13.5a6 6 0 0 1 12 0V25z" fill="#F4B728"></path>
              <circle cx="19" cy="19.5" r="1.3" fill="#0E5A3C"></circle>
            </svg>
            <span style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: "800", fontSize: "22px", letterSpacing: "-0.03em" }}>
              plainly
            </span>
            <span style={{ height: "26px", padding: "0 10px", display: "inline-flex", alignItems: "center", borderRadius: "6px", background: "#15201A", color: "#FFFFFF", fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase" }}>
              Back office
            </span>
          </Link>
          <label style={{ flex: "1 1 220px", maxWidth: "360px", height: "42px", boxSizing: "border-box", display: "flex", alignItems: "center", gap: "10px", padding: "0 14px", background: "#F6F4EE", border: "1px solid #E3DFD4", borderRadius: "12px" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5E6862" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="11" cy="11" r="7"></circle>
              <path d="m20 20-3.5-3.5"></path>
            </svg>
            <span style={{ position: "absolute", width: "1px", height: "1px", overflow: "hidden", clip: "rect(0 0 0 0)" }}>
              Search case, listing or user ID
            </span>
            <input type="search" placeholder="Case, listing or user ID" style={{ flex: "1", minWidth: "0", border: "0", outline: "none", background: "transparent", font: "500 14px 'Figtree', sans-serif", color: "#15201A" }} />
          </label>
          <div style={{ marginLeft: "auto", display: "flex", flexWrap: "wrap", alignItems: "center", gap: "8px" }}>
            <span style={{ height: "30px", padding: "0 10px", display: "inline-flex", alignItems: "center", gap: "6px", borderRadius: "999px", background: "#E5EEFB", color: "#164A90", fontSize: "12px", fontWeight: "700" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#164A90" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M3 3l18 18"></path>
                <path d="M10.6 6.1A9.6 9.6 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-2.9 3.3M6.2 7.6C4.2 9.1 3 12 3 12s4 6 9 6a8.6 8.6 0 0 0 3.6-.8"></path>
              </svg>
              PII masked by default
            </span>
            <button type="button" aria-label="Notifications" style={{ width: "44px", height: "44px", borderRadius: "999px", border: "0", background: "transparent", display: "grid", placeItems: "center" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#15201A" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"></path>
                <path d="M10 21h4"></path>
              </svg>
            </button>
            <span style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ width: "34px", height: "34px", borderRadius: "999px", background: "#15201A", color: "#FFFFFF", display: "grid", placeItems: "center", fontWeight: "700", fontSize: "13px" }}>
                IN
              </span>
              <span style={{ display: "flex", flexDirection: "column", lineHeight: "1.2" }}>
                <strong style={{ fontSize: "14px" }}>
                  Ifeoma N.
                </strong>
                <span style={{ fontSize: "12px", color: "#5E6862" }}>
                  Operations admin
                </span>
              </span>
            </span>
          </div>
        </header>
        <div style={{ flex: "1", display: "flex", flexWrap: "wrap", alignItems: "stretch" }}>
          <nav aria-label="Back office" style={{ flex: "1 1 248px", maxWidth: "248px", boxSizing: "border-box", background: "#15201A", padding: "20px 12px", display: "flex", flexDirection: "column", gap: "2px" }}>
            <span style={{ padding: "4px 12px 6px", fontSize: "11px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#8E9A93" }}>
              Queues
            </span>
            <Link href="/admin/verification" style={{ height: "44px", padding: "0 12px 0 22px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="12" cy="8" r="4"></circle>
                <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"></path>
              </svg>
              KYC exceptions
            </Link>
            <Link href="/admin/verification" style={{ height: "44px", padding: "0 12px 0 22px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"></path>
              </svg>
              Ownership
            </Link>
            <Link href="/admin/verification" style={{ height: "44px", padding: "0 12px 0 22px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M6 3h8l4 4v14H6z"></path>
                <path d="M14 3v4h4M9 12h6M9 16h6"></path>
              </svg>
              Title
            </Link>
            <Link href="/admin/verification" style={{ height: "44px", padding: "0 12px 0 22px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"></path>
                <path d="m8.5 12 2.5 2.5 4.5-5"></path>
              </svg>
              Agents
            </Link>
            <span style={{ height: "1px", background: "#26342C", margin: "10px 4px" }}></span>
            <Link href="/admin/moderation" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 21V4M5 4h11l-2 4 2 4H5"></path>
              </svg>
              Moderation
            </Link>
            <Link href="/admin/disputes" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 5h16v11H9l-5 4z"></path>
              </svg>
              Disputes
            </Link>
            <Link href="/admin/leakage" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M7 20V4l10 16V4M4 10h16M4 14h16"></path>
              </svg>
              Leakage cases
            </Link>
            <Link href="/admin/leakage" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 4 2.5 20h19z"></path>
                <path d="M12 10v4M12 17h.01"></path>
              </svg>
              Fraud ops
            </Link>
            <Link href="/admin/revenue" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M3 10 12 4l9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"></path>
              </svg>
              Revenue
            </Link>
            <Link href="/admin/config" aria-current="page" style={{ minHeight: "44px", padding: "6px 12px", boxSizing: "border-box", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", background: "#26342C", color: "#FFFFFF", fontWeight: "700", fontSize: "14px", position: "relative" }}>
              <span style={{ position: "absolute", left: "4px", top: "50%", width: "6px", height: "6px", marginTop: "-3px", borderRadius: "99px", background: "#F4B728" }} aria-hidden="true"></span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flex: "none" }}>
                <path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"></path>
                <circle cx="16" cy="6" r="2"></circle>
                <circle cx="10" cy="12" r="2"></circle>
                <circle cx="18" cy="18" r="2"></circle>
              </svg>
              <span style={{ display: "flex", flexDirection: "column", lineHeight: "1.25" }}>
                Config
                <span style={{ fontSize: "12px", fontWeight: "500", color: "#C9D2CC" }}>
                  Two-person approval
                </span>
              </span>
              <span style={{ marginLeft: "auto", minWidth: "22px", height: "22px", padding: "0 7px", boxSizing: "border-box", borderRadius: "999px", background: "#F4B728", color: "#15201A", fontSize: "12px", fontWeight: "700", display: "grid", placeItems: "center" }}>
                2
              </span>
            </Link>
            <Link href="/admin/config" style={{ height: "44px", padding: "0 12px", display: "flex", alignItems: "center", gap: "12px", borderRadius: "10px", textDecoration: "none", color: "#C9D2CC", fontWeight: "600", fontSize: "14px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C9D2CC" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"></path>
              </svg>
              Audit log
            </Link>
            <span style={{ marginTop: "16px", padding: "12px", borderRadius: "12px", background: "#1D2A23", color: "#C9D2CC", fontSize: "12px", lineHeight: "1.45", display: "flex", gap: "8px" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F4B728" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flex: "none" }}>
                <rect x="5" y="11" width="14" height="10" rx="2"></rect>
                <path d="M8 11V8a4 4 0 0 1 8 0v3"></path>
              </svg>
              Least-privilege role. Every action is audited.
            </span>
          </nav>
          <main style={{ flex: "999 1 560px", minWidth: "0", boxSizing: "border-box", padding: "32px" }}>
            <div style={{ maxWidth: "1280px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "20px" }}>
              <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "12px 20px" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
                  <span style={{ fontSize: "12px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#0E5A3C" }}>
                    Platform rules
                  </span>
                  <h1 style={{ margin: "0", fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: "700", fontSize: "34px", lineHeight: "1.1", letterSpacing: "-0.02em" }}>
                    Configuration
                  </h1>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                  <span style={{ height: "30px", padding: "0 10px", display: "inline-flex", alignItems: "center", gap: "6px", borderRadius: "999px", background: "#E5EEFB", color: "#164A90", fontSize: "12px", fontWeight: "700" }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#164A90" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <circle cx="12" cy="8" r="4"></circle>
                      <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"></path>
                    </svg>
                    Every change needs two people
                  </span>
                  <span style={{ height: "30px", padding: "0 10px", display: "inline-flex", alignItems: "center", gap: "6px", borderRadius: "999px", background: "#FDF3D3", color: "#6B4E00", fontSize: "12px", fontWeight: "700" }}>
                    <span style={{ width: "7px", height: "7px", borderRadius: "9px", background: "#F4B728" }}></span>
                    2 changes awaiting approval
                  </span>
                </div>
              </div>
              <section aria-labelledby="pend-h" style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <h2 id="pend-h" style={{ margin: "0", fontSize: "20px", fontWeight: "700" }}>
                  Awaiting second approver
                </h2>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(420px, 100%), 1fr))", gap: "12px" }}>
                  <article style={{ background: "#FFFFFF", border: "1.5px solid #15201A", borderRadius: "16px", padding: "18px 20px", display: "flex", flexDirection: "column", gap: "12px", boxShadow: "0 8px 24px -8px rgba(21,32,26,.22)" }}>
                    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
                      <span style={{ fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                        Fees · CHG-0412
                      </span>
                      <span style={{ height: "26px", padding: "0 9px", display: "inline-flex", alignItems: "center", gap: "5px", borderRadius: "999px", background: "#FDF3D3", color: "#6B4E00", fontSize: "12px", fontWeight: "700" }}>
                        <span style={{ width: "7px", height: "7px", borderRadius: "9px", background: "#F4B728" }}></span>
                        Awaiting second approver
                      </span>
                    </div>
                    <strong style={{ fontSize: "17px" }}>
                      Closing-fee minimum
                    </strong>
                    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px", fontVariantNumeric: "tabular-nums" }}>
                      <span style={{ padding: "6px 12px", borderRadius: "10px", background: "#EFECE4", fontSize: "15px", fontWeight: "600", color: "#3D4A43", textDecoration: "line-through" }}>
                        ₦15,000
                      </span>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3D4A43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M5 12h14M13 6l6 6-6 6"></path>
                      </svg>
                      <span style={{ padding: "6px 12px", borderRadius: "10px", background: "#E2F0E7", fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "20px", fontWeight: "700", color: "#0A4630" }}>
                        ₦20,000
                      </span>
                    </div>
                    <dl style={{ margin: "0", display: "grid", gridTemplateColumns: "auto 1fr", gap: "4px 12px", fontSize: "13px" }}>
                      <dt style={{ color: "#5E6862" }}>
                        Proposed by
                      </dt>
                      <dd style={{ margin: "0" }}>
                        Kemi O. · Mon 12 Oct 17:05
                      </dd>
                      <dt style={{ color: "#5E6862" }}>
                        Reason
                      </dt>
                      <dd style={{ margin: "0", color: "#3D4A43" }}>
                        Low-rent closes cost more to process than the current minimum earns.
                      </dd>
                      <dt style={{ color: "#5E6862" }}>
                        Applies to
                      </dt>
                      <dd style={{ margin: "0", color: "#3D4A43" }}>
                        Deals accepted after approval. Open deals keep today's fee.
                      </dd>
                    </dl>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                      <button type="button" style={{ height: "44px", padding: "0 18px", border: "0", borderRadius: "12px", background: "#0E5A3C", color: "#FFFFFF", font: "700 14px 'Figtree', sans-serif", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <path d="m5 12.5 4.5 4.5L19 7.5"></path>
                        </svg>
                        Approve
                      </button>
                      <button type="button" style={{ height: "44px", padding: "0 18px", borderRadius: "12px", background: "#FFFFFF", border: "1.5px solid #B3261E", color: "#B3261E", font: "700 14px 'Figtree', sans-serif" }}>
                        Reject
                      </button>
                    </div>
                  </article>
                  <article style={{ background: "#FFFFFF", border: "1px solid #E3DFD4", borderRadius: "16px", padding: "18px 20px", display: "flex", flexDirection: "column", gap: "12px", boxShadow: "0 1px 2px rgba(21,32,26,.06)" }}>
                    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
                      <span style={{ fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                        Limits · CHG-0413
                      </span>
                      <span style={{ height: "26px", padding: "0 9px", display: "inline-flex", alignItems: "center", gap: "5px", borderRadius: "999px", background: "#FDF3D3", color: "#6B4E00", fontSize: "12px", fontWeight: "700" }}>
                        <span style={{ width: "7px", height: "7px", borderRadius: "9px", background: "#F4B728" }}></span>
                        Awaiting second approver
                      </span>
                    </div>
                    <strong style={{ fontSize: "17px" }}>
                      Viewings per seeker
                    </strong>
                    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px", fontVariantNumeric: "tabular-nums" }}>
                      <span style={{ padding: "6px 12px", borderRadius: "10px", background: "#EFECE4", fontSize: "15px", fontWeight: "600", color: "#3D4A43", textDecoration: "line-through" }}>
                        8 per 7 days
                      </span>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3D4A43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M5 12h14M13 6l6 6-6 6"></path>
                      </svg>
                      <span style={{ padding: "6px 12px", borderRadius: "10px", background: "#E2F0E7", fontFamily: "'Bricolage Grotesque', sans-serif", fontSize: "20px", fontWeight: "700", color: "#0A4630" }}>
                        10 per 7 days
                      </span>
                    </div>
                    <dl style={{ margin: "0", display: "grid", gridTemplateColumns: "auto 1fr", gap: "4px 12px", fontSize: "13px" }}>
                      <dt style={{ color: "#5E6862" }}>
                        Proposed by
                      </dt>
                      <dd style={{ margin: "0" }}>
                        You · Tue 13 Oct 09:20
                      </dd>
                      <dt style={{ color: "#5E6862" }}>
                        Reason
                      </dt>
                      <dd style={{ margin: "0", color: "#3D4A43" }}>
                        Seekers in high-demand areas hit the cap before finding a match.
                      </dd>
                    </dl>
                    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "8px" }}>
                      <span className="tip">
                        {" "}
                        <button type="button" disabled aria-describedby="own-tip" style={{ height: "44px", padding: "0 18px", border: "0", borderRadius: "12px", background: "#EFECE4", color: "#5E6862", font: "700 14px 'Figtree', sans-serif" }}>
                          Approve
                        </button>
                        {" "}
                        <span role="tooltip" id="own-tip">
                          You proposed this change, so you can't approve it. Another admin must decide.
                        </span>
                        {" "}
                      </span>
                      <button type="button" style={{ height: "44px", padding: "0 18px", borderRadius: "12px", background: "#FFFFFF", border: "1.5px solid #15201A", color: "#15201A", font: "700 14px 'Figtree', sans-serif" }}>
                        Withdraw
                      </button>
                    </div>
                    <span style={{ fontSize: "12px", color: "#5E6862" }}>
                      You can't approve your own change. Kemi O. and Tunde A. have been asked.
                    </span>
                  </article>
                </div>
              </section>
              <div style={{ display: "flex", flexWrap: "wrap", alignItems: "flex-start", gap: "20px" }}>
                <section aria-labelledby="cfg-h" style={{ flex: "999 1 560px", minWidth: "0", background: "#FFFFFF", border: "1px solid #E3DFD4", borderRadius: "16px", overflow: "hidden", boxShadow: "0 1px 2px rgba(21,32,26,.06)" }}>
                  <div style={{ padding: "16px 20px", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "8px 16px", borderBottom: "1px solid #E3DFD4" }}>
                    <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
                      <h2 id="cfg-h" style={{ margin: "0", fontSize: "18px", fontWeight: "700" }}>
                        Live settings
                      </h2>
                      <span style={{ fontSize: "13px", color: "#5E6862" }}>
                        Changes are proposed, approved by a second admin, then versioned
                      </span>
                    </div>
                    <label style={{ height: "40px", boxSizing: "border-box", display: "flex", alignItems: "center", gap: "8px", padding: "0 12px", background: "#F6F4EE", border: "1px solid #E3DFD4", borderRadius: "10px", flex: "0 1 240px" }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5E6862" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <circle cx="11" cy="11" r="7"></circle>
                        <path d="m20 20-3.5-3.5"></path>
                      </svg>
                      <span style={{ position: "absolute", width: "1px", height: "1px", overflow: "hidden", clip: "rect(0 0 0 0)" }}>
                        Filter settings
                      </span>
                      <input type="search" placeholder="Filter settings" style={{ flex: "1", minWidth: "0", border: "0", outline: "none", background: "transparent", font: "500 14px 'Figtree', sans-serif", color: "#15201A" }} />
                    </label>
                  </div>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", minWidth: "760px", borderCollapse: "collapse", fontSize: "14px" }}>
                      <thead>
                        <tr style={{ textAlign: "left" }}>
                          <th scope="col" style={{ padding: "10px 20px", fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                            Setting
                          </th>
                          <th scope="col" style={{ padding: "10px 12px", fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                            Value
                          </th>
                          <th scope="col" style={{ padding: "10px 12px", fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                            Version
                          </th>
                          <th scope="col" style={{ padding: "10px 12px", fontSize: "12px", fontWeight: "700", letterSpacing: "0.06em", textTransform: "uppercase", color: "#5E6862" }}>
                            Last changed
                          </th>
                          <th scope="col" style={{ padding: "10px 20px 10px 12px" }}>
                            <span style={{ position: "absolute", width: "1px", height: "1px", overflow: "hidden", clip: "rect(0 0 0 0)" }}>
                              Action
                            </span>
                          </th>
                        </tr>
                      </thead>
                      <tbody style={{ fontVariantNumeric: "tabular-nums" }}>
                        <tr style={{ background: "#EFECE4" }}>
                          <th scope="rowgroup" colSpan="5" style={{ padding: "8px 20px", textAlign: "left", fontSize: "12px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#3D4A43" }}>
                            Fees
                          </th>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            {"Listing fee bands "}
                            <span style={{ display: "block", fontSize: "12px", fontWeight: "500", color: "#5E6862" }}>
                              per 90 days, by annual rent
                            </span>
                          </th>
                          <td style={{ padding: "11px 12px", fontSize: "13px" }}>
                            {"<₦1m ₦5,000 · ₦1m–₦3m ₦10,000"}
                            <br />
                            {"₦3m–₦10m ₦20,000 · >₦10m ₦35,000"}
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v2
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            1 Sep 2026 · Kemi O.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4", background: "#FDF3D3" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            {"Closing fee "}
                            <span style={{ display: "block", fontSize: "12px", fontWeight: "500", color: "#6B4E00" }}>
                              Change pending · CHG-0412
                            </span>
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            3% of first year's rent, min ₦15,000
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v3
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            1 Sep 2026 · Kemi O.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" disabled style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#EFECE4", border: "0", color: "#5E6862", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Locked
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Introduction-fee window
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            12 months from first introduction
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                      </tbody>
                      <tbody style={{ fontVariantNumeric: "tabular-nums" }}>
                        <tr style={{ background: "#EFECE4" }}>
                          <th scope="rowgroup" colSpan="5" style={{ padding: "8px 20px", textAlign: "left", fontSize: "12px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#3D4A43" }}>
                            Limits
                          </th>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Advance cap · Lagos
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            12 months (Fair Terms)
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Agent fee cap
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            10% of annual rent
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4", background: "#FDF3D3" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            {"Viewings per seeker "}
                            <span style={{ display: "block", fontSize: "12px", fontWeight: "500", color: "#6B4E00" }}>
                              Change pending · CHG-0413
                            </span>
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            8 per 7 days
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" disabled style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#EFECE4", border: "0", color: "#5E6862", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Locked
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Active applications per seeker
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            5
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Strike thresholds
                          </th>
                          <td style={{ padding: "11px 12px", fontSize: "13px" }}>
                            1st warning · 2nd in 90 days: chat limited 24 h
                            <br />
                            3rd: listings paused · 4th: suspended
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v2
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            22 Sep 2026 · Ifeoma N.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                      </tbody>
                      <tbody style={{ fontVariantNumeric: "tabular-nums" }}>
                        <tr style={{ background: "#EFECE4" }}>
                          <th scope="rowgroup" colSpan="5" style={{ padding: "8px 20px", textAlign: "left", fontSize: "12px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#3D4A43" }}>
                            SLAs
                          </th>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Verification decision
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            24 h
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Listing moderation
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            4 business hours
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                      </tbody>
                      <tbody style={{ fontVariantNumeric: "tabular-nums" }}>
                        <tr style={{ background: "#EFECE4" }}>
                          <th scope="rowgroup" colSpan="5" style={{ padding: "8px 20px", textAlign: "left", fontSize: "12px", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase", color: "#3D4A43" }}>
                            Areas
                          </th>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Fee switch-on · Yaba
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            <span style={{ height: "26px", padding: "0 9px", display: "inline-flex", alignItems: "center", gap: "5px", borderRadius: "999px", background: "#E3F4EA", color: "#145C37", fontSize: "12px", fontWeight: "700" }}>
                              <span style={{ width: "7px", height: "7px", borderRadius: "9px", background: "#1C7A4A" }}></span>
                              On
                            </span>
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v2
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            1 Sep 2026 · Kemi O.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Fee switch-on · Surulere
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            <span style={{ height: "26px", padding: "0 9px", display: "inline-flex", alignItems: "center", gap: "5px", borderRadius: "999px", background: "#E3F4EA", color: "#145C37", fontSize: "12px", fontWeight: "700" }}>
                              <span style={{ width: "7px", height: "7px", borderRadius: "9px", background: "#1C7A4A" }}></span>
                              On
                            </span>
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v2
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            1 Sep 2026 · Kemi O.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Fee switch-on · Lekki Phase 1
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            <span style={{ display: "inline-flex", flexWrap: "wrap", alignItems: "center", gap: "6px" }}>
                              <span style={{ height: "26px", padding: "0 9px", display: "inline-flex", alignItems: "center", gap: "5px", borderRadius: "999px", background: "#EFECE4", color: "#3D4A43", fontSize: "12px", fontWeight: "700" }}>
                                <span style={{ width: "7px", height: "7px", borderRadius: "9px", border: "1.5px solid #5E6862", boxSizing: "border-box" }}></span>
                                Off
                              </span>
                              <span style={{ fontSize: "12px", color: "#5E6862" }}>
                                Founding period, listings free
                              </span>
                            </span>
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                        <tr style={{ borderTop: "1px solid #EFECE4" }}>
                          <th scope="row" style={{ padding: "11px 20px", textAlign: "left", fontWeight: "600" }}>
                            Live cities
                          </th>
                          <td style={{ padding: "11px 12px" }}>
                            Lagos
                          </td>
                          <td style={{ padding: "11px 12px", color: "#3D4A43" }}>
                            v1
                          </td>
                          <td style={{ padding: "11px 12px", fontSize: "13px", color: "#3D4A43" }}>
                            Launch · Tunde A.
                          </td>
                          <td style={{ padding: "11px 20px 11px 12px" }}>
                            <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "1px solid #CFC9BA", color: "#15201A", font: "600 13px 'Figtree', sans-serif", whiteSpace: "nowrap" }}>
                              Propose change
                            </button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </section>
                <aside style={{ flex: "1 1 320px", minWidth: "0", display: "flex", flexDirection: "column", gap: "20px" }}>
                  <section aria-labelledby="vh-h" style={{ background: "#FFFFFF", border: "1px solid #E3DFD4", borderRadius: "16px", padding: "18px 20px", display: "flex", flexDirection: "column", gap: "12px", boxShadow: "0 1px 2px rgba(21,32,26,.06)" }}>
                    <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
                      <h3 id="vh-h" style={{ margin: "0", fontSize: "16px", fontWeight: "700" }}>
                        Version history · Closing fee
                      </h3>
                      <span style={{ fontSize: "13px", color: "#5E6862" }}>
                        Each version records who proposed and who approved
                      </span>
                    </div>
                    <ol style={{ margin: "0", padding: "0", listStyle: "none", display: "flex", flexDirection: "column", gap: "10px", fontSize: "13px" }}>
                      <li style={{ padding: "10px 12px", borderRadius: "12px", background: "#FDF3D3", display: "flex", flexDirection: "column", gap: "2px" }}>
                        <span style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                          <strong>
                            v4 · proposed
                          </strong>
                          <span style={{ color: "#6B4E00", fontVariantNumeric: "tabular-nums" }}>
                            12 Oct 2026
                          </span>
                        </span>
                        <span style={{ color: "#3D4A43" }}>
                          3%, min ₦20,000 · Kemi O. · awaiting approver
                        </span>
                      </li>
                      <li style={{ padding: "10px 12px", borderRadius: "12px", border: "1.5px solid #0E5A3C", display: "flex", flexDirection: "column", gap: "2px" }}>
                        <span style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                          <strong>
                            v3 · live
                          </strong>
                          <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                            1 Sep 2026
                          </span>
                        </span>
                        <span style={{ color: "#3D4A43" }}>
                          3%, min ₦15,000, less listing fee · Kemi O. → Tunde A.
                        </span>
                      </li>
                      <li style={{ padding: "10px 12px", borderRadius: "12px", background: "#F6F4EE", display: "flex", flexDirection: "column", gap: "2px" }}>
                        <span style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                          <strong>
                            v2
                          </strong>
                          <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                            4 Aug 2026
                          </span>
                        </span>
                        <span style={{ color: "#3D4A43" }}>
                          3%, min ₦15,000 · Tunde A. → Ifeoma N.
                        </span>
                      </li>
                      <li style={{ padding: "10px 12px", borderRadius: "12px", background: "#F6F4EE", display: "flex", flexDirection: "column", gap: "2px" }}>
                        <span style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                          <strong>
                            v1
                          </strong>
                          <span style={{ color: "#5E6862" }}>
                            Launch
                          </span>
                        </span>
                        <span style={{ color: "#3D4A43" }}>
                          Set at launch from the business rules
                        </span>
                      </li>
                    </ol>
                    <button type="button" style={{ alignSelf: "flex-start", height: "40px", padding: "0 14px", borderRadius: "10px", background: "#FFFFFF", border: "1.5px solid #15201A", color: "#15201A", font: "700 13px 'Figtree', sans-serif" }}>
                      Compare versions
                    </button>
                  </section>
                  <section aria-labelledby="al-h" style={{ background: "#FFFFFF", border: "1px solid #E3DFD4", borderRadius: "16px", padding: "18px 20px", display: "flex", flexDirection: "column", gap: "12px", boxShadow: "0 1px 2px rgba(21,32,26,.06)" }}>
                    <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "8px" }}>
                      <h3 id="al-h" style={{ margin: "0", fontSize: "16px", fontWeight: "700" }}>
                        Audit log
                      </h3>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: "4px", fontSize: "12px", color: "#5E6862" }}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#5E6862" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <rect x="5" y="11" width="14" height="10" rx="2"></rect>
                          <path d="M8 11V8a4 4 0 0 1 8 0v3"></path>
                        </svg>
                        Append-only
                      </span>
                    </div>
                    <ol style={{ margin: "0", padding: "0", listStyle: "none", display: "flex", flexDirection: "column", fontSize: "13px" }}>
                      <li style={{ display: "grid", gridTemplateColumns: "52px 1fr", gap: "10px", padding: "9px 0", borderBottom: "1px solid #EFECE4" }}>
                        <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                          09:20
                        </span>
                        <span>
                          <strong>
                            Ifeoma N.
                          </strong>
                          {" proposed CHG-0413 · viewings 8 → 10"}
                        </span>
                      </li>
                      <li style={{ display: "grid", gridTemplateColumns: "52px 1fr", gap: "10px", padding: "9px 0", borderBottom: "1px solid #EFECE4" }}>
                        <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                          08:41
                        </span>
                        <span>
                          <strong>
                            Tunde A.
                          </strong>
                          {" approved OV-55102 · Owner verified"}
                        </span>
                      </li>
                      <li style={{ display: "grid", gridTemplateColumns: "52px 1fr", gap: "10px", padding: "9px 0", borderBottom: "1px solid #EFECE4" }}>
                        <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                          08:02
                        </span>
                        <span>
                          <strong>
                            Bola I.
                          </strong>
                          {" saved a draft decision on DSP-0087"}
                        </span>
                      </li>
                      <li style={{ display: "grid", gridTemplateColumns: "52px 1fr", gap: "10px", padding: "9px 0", borderBottom: "1px solid #EFECE4" }}>
                        <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                          Mon
                        </span>
                        <span>
                          <strong>
                            Kemi O.
                          </strong>
                          {" proposed CHG-0412 · closing-fee minimum"}
                        </span>
                      </li>
                      <li style={{ display: "grid", gridTemplateColumns: "52px 1fr", gap: "10px", padding: "9px 0" }}>
                        <span style={{ color: "#5E6862", fontVariantNumeric: "tabular-nums" }}>
                          Mon
                        </span>
                        <span>
                          <strong>
                            Kemi O.
                          </strong>
                          {" submitted LK-0391 for four-eyes approval"}
                        </span>
                      </li>
                    </ol>
                    <Link href="/admin/config" style={{ display: "inline-flex", alignItems: "center", gap: "6px", fontSize: "14px", fontWeight: "600", textDecoration: "none", paddingTop: "10px", borderTop: "1px solid #E3DFD4" }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0E5A3C" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"></path>
                      </svg>
                      Open full audit log
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0E5A3C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="m9 6 6 6-6 6"></path>
                      </svg>
                    </Link>
                  </section>
                </aside>
              </div>
            </div>
          </main>
        </div>
      </div>
    </>
  );
}
